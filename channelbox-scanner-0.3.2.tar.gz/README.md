# ChannelBox Scanner

## Manual full scan (0.3.2)

In Home Assistant's app Configuration, increase `full_scan_request` by one
(0 to 1 for the first request), save, then restart the app. This requests one
full scan immediately, including previously excluded channels. The completed
request is saved with the scan results, so restarting again does not repeat it.
A failed scan remains pending; a failed GitHub upload retries publication without
repeating the scan. Daily and weekly scheduling continues from this full scan.
The existing playlist stays available while the scan runs.

## 0.3.1: HLS compatibility and Grit Xtra

The FFmpeg probe uses `-extension_picky 0` so valid HLS streams with unusual URL
suffixes can decode. Standard HLS extension allowlists, the HTTP/HTTPS transport
allowlist, the 20-second timeout, and the requirement for successfully decoded
video remain in place. This does not automatically mark any channel healthy.

On upgrade, an existing scanner checks Grit Xtra once without changing national
scan dates or incrementing failed-cycle counters. It publishes Grit only if the
probe passes, preserving its reserved number 187. Grit is also retried during
daily scans when inactive; other excluded national feeds remain part of the
weekly full scan. Existing app data and the number registry must be retained
when updating. The Pi players are not reconfigured by this scanner update.

The narrower option alone decoded Grit on the Mac; regression checks cover
failure rejection, daily retry, number preservation, and upgrade scheduling.
The separate Pi 5 playback test confirmed picture and sound with relaxed HLS
checks. See the deployment record for verification inside Home Assistant.

Checks public US channels from IPTV-org on your home network. This app has no access to Home Assistant devices, configuration, Supervisor API, host networking, or host files. Its only persistent storage is its own /data directory. No inbound ports are exposed.

Four concurrent FFmpeg processes by default each attempt to decode three seconds of video, with a 20-second wall-clock limit. A responding webpage or playlist alone does not pass. Audio is decoded if supplied but the check cannot prove audible sound or the advertised program. Some channels are geoblocked or off-air when checked.

The first run performs a full scan at/after 4 AM America/Chicago. Daily runs recheck active entries; every seven days a full scan includes previously failed entries and new US channels. A missed weekly scan runs after the server comes back. A full first scan can take several hours. Daily scans run on the server even when the Mac and ChannelBox player are off.

New channels enter only after a successful decode. Existing entries are removed after three failed daily scan cycles. If more than half the tested established channels fail, the entire run is withheld without advancing failure counters. Changed addresses fall back to the previous verified address when it still works. Channel numbers never get reused; the bundled seed preserves all 1,479 existing ChannelBox assignments.

## Options

- timezone: America/Chicago
- scan_hour: 4 (daily at the first scheduler check after this hour)
- workers: 4; configurable from 1 to 8; reduce if your server or connection needs less load
- full_scan_request: 0 initially; increase by one to request a full scan
- github_repository: cycle252/channelbox-playlist
- github_token: a fine-grained GitHub token restricted to this repository, with Contents read/write; enter directly in Home Assistant, never in a chat or repository

The repository must exist with a main branch. Publication replaces one channels.json file atomically via GitHub's Contents API. A failed upload is retried without rescan or extra failure counts. The generated M3U is retained locally in /data/channels.m3u. Token expiry requires renewal in app options. Never expose /data over HTTP: options.json contains the token.

## Local installation

Extract the reviewed scanner bundle into /local_apps/channelbox_scanner using the Terminal & SSH app. In Settings → Apps → Install app, check for updates and locate ChannelBox Scanner under Local apps. Install it, enter options, start it, then view the log. On older Home Assistant installations the local app directory may be /addons instead.

Do not run scanner.py manually while the app is running; a file lock prevents overlapping scans. Keep the app's data in backups: its scanner-state.json reserves all channel numbers forever and records stream health. Losing this file can lose assignments for channels discovered after the initial seed.

The TV box can be configured while the first scan is running: an unpublished feed leaves its cached playlist intact. Verify the first GitHub upload and TV box adoption before considering the rollout complete.

## Arkansas-first lineup (0.2.0)

Verified local feeds are published first: THV11, 5NEWS, Arkansas PBS/KETS if it
recovers, and VTN. This is display order, not renumbering. Other channels keep
numeric order. THV11 and 5NEWS live addresses are resolved from their official
watch pages on each daily/full scan, and inactive local additions are also
retried daily. A page failure falls back to the last verified address under the
same three-failed-cycle policy. Only successful video decoding admits a feed.
These are station news streams, not full CBS broadcast simulcasts.

On upgrading an established installation, one short local-only check adds the
new feeds and republishes the order. It does not advance the nationwide daily
or weekly scan dates or count new failures against existing channels. Channel
numbers, including numbers reserved for removed entries, remain unchanged.

## Memphis / Mid-South checks (0.3.0)

Local coverage also includes Memphis and Jackson, Tennessee. ABC24's official
live-player page and FOX13 Memphis's explicitly labelled live VideoObject are
resolved each scan. Clips or ambiguous FOX13 pages are rejected. Exact upstream
feeds for KTEJ, statewide Arkansas TV/KETS, WMC, WJKT, WATN and WHBQ are checked
daily even when inactive. A missing feed is logged as unavailable and retried;
a station website alone never qualifies a channel for publication. WMC and WJKT
currently have no direct feed in the upstream list. No browser playback, account,
geolocation or DRM restrictions are bypassed.

Successful additions join the local section after the existing Arkansas entries;
failed candidates stay out of the active lineup. Local-only upgrade checks do
not advance the nationwide scan schedule or failure counts. The next regular
daily scan applies the usual three-failure retention policy to existing entries.
