# ChannelBox Scanner

Checks public US channels from IPTV-org on your home network. This app has no access to Home Assistant devices, configuration, Supervisor API, host networking, or host files. Its only persistent storage is its own /data directory. No inbound ports are exposed.

Two concurrent FFmpeg processes each attempt to decode three seconds of video, with a 20-second wall-clock limit. A responding webpage or playlist alone does not pass. Audio is decoded if supplied but the check cannot prove audible sound or the advertised program. Some channels are geoblocked or off-air when checked.

The first run performs a full scan at/after 4 AM America/Chicago. Daily runs recheck active entries; every seven days a full scan includes previously failed entries and new US channels. A missed weekly scan runs after the server comes back. A full first scan can take several hours. Daily scans run on the server even when the Mac and ChannelBox player are off.

New channels enter only after a successful decode. Existing entries are removed after three failed daily scan cycles. If more than half the tested established channels fail, the entire run is withheld without advancing failure counters. Changed addresses fall back to the previous verified address when it still works. Channel numbers never get reused; the bundled seed preserves all 1,479 existing ChannelBox assignments.

## Options

- timezone: America/Chicago
- scan_hour: 4 (daily at the first scheduler check after this hour)
- workers: 2; reduce to 1 if your server needs less load
- github_repository: cycle252/channelbox-playlist
- github_token: a fine-grained GitHub token restricted to this repository, with Contents read/write; enter directly in Home Assistant, never in a chat or repository

The repository must exist with a main branch. Publication replaces one channels.json file atomically via GitHub's Contents API. A failed upload is retried without rescan or extra failure counts. The generated M3U is retained locally in /data/channels.m3u. Token expiry requires renewal in app options. Never expose /data over HTTP: options.json contains the token.

## Local installation

Extract the reviewed scanner bundle into /local_apps/channelbox_scanner using the Terminal & SSH app. In Settings → Apps → Install app, check for updates and locate ChannelBox Scanner under Local apps. Install it, enter options, start it, then view the log. On older Home Assistant installations the local app directory may be /addons instead.

Do not run scanner.py manually while the app is running; a file lock prevents overlapping scans. Keep the app's data in backups: its scanner-state.json reserves all channel numbers forever and records stream health. Losing this file can lose assignments for channels discovered after the initial seed.

The first complete scan and GitHub upload must be verified before enabling downloads on the TV box.
