#!/usr/bin/env python3
"""Home-network stream checks; only decoded video qualifies for admission."""
from __future__ import annotations

import argparse
import base64
import copy
import fcntl
import json
import logging
import re
import subprocess
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

from channelbox_feed import atomic_write, download, render_m3u, validate_feed, web_url

SOURCE = 'https://iptv-org.github.io/iptv/countries/us.m3u'
LOG = logging.getLogger('scanner')
ATTR = re.compile(r'([\w-]+)="([^"]*)"')


def parse_source(text):
    entries, current = {}, None
    if not text.lstrip('\ufeff').startswith('#EXTM3U'):
        raise ValueError('Upstream is not M3U')
    for line in text.splitlines():
        line = line.strip()
        if line.startswith('#EXTINF:'):
            a = dict(ATTR.findall(line))
            current = dict(id=a.get('tvg-id', ''), name=line.split(',', 1)[-1],
                           group=a.get('group-title', ''), user_agent='', referrer='')
        elif line.startswith('#EXTVLCOPT:') and current:
            key, _, value = line[11:].partition('=')
            field = {'http-user-agent': 'user_agent', 'http-referrer': 'referrer'}.get(key)
            if field:
                current[field] = value
        elif line and not line.startswith('#'):
            if not current or not current['id'] or current['id'] in entries:
                raise ValueError('Missing or duplicate upstream identity')
            current['url'] = web_url(line)
            entries[current['id']] = current
            current = None
    if not entries or current:
        raise ValueError('Empty or truncated source')
    return entries


def probe(channel, timeout=20):
    command = ['ffmpeg', '-nostdin', '-hide_banner', '-loglevel', 'error',
               '-threads', '1', '-rw_timeout', '8000000',
               '-protocol_whitelist', 'http,https,tcp,tls,crypto']
    for field, flag in [('user_agent', '-user_agent'), ('referrer', '-referer')]:
        if channel.get(field):
            command += [flag, channel[field]]
    command += ['-i', channel['url'], '-map', '0:v:0', '-map', '0:a:0?',
                '-t', '3', '-threads', '1', '-progress', 'pipe:1', '-nostats', '-f', 'null', '-']
    try:
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                timeout=timeout, check=False, text=True)
        frames = [int(x) for x in re.findall(r'^frame=(\d+)\s*$', result.stdout, re.M)]
        return result.returncode == 0 and bool(frames) and max(frames) >= 2
    except subprocess.TimeoutExpired:
        return False


def evolve(state, upstream, results, full, now, threshold=3):
    """Failed cycles are independent dates, not immediate retries."""
    new = copy.deepcopy(state)
    registry, records = new['numbers'], new.setdefault('records', {})
    used = set(registry.values())
    next_number = max([999] + [int(n) for n in used]) + 1
    for identity in sorted(upstream):
        if identity not in registry:
            if next_number > 9999:
                raise ValueError('Channel numbers exhausted')
            registry[identity] = str(next_number)
            next_number += 1
    prior_active = {i for i, r in records.items() if r.get('active')}
    tested_active = prior_active & results.keys()
    # An outage should not progressively erase the last working lineup.
    if tested_active and sum(bool(results[i]) for i in tested_active) < len(tested_active) * 0.5:
        raise ValueError('Most established channels failed; keeping last good list')
    for identity, good in results.items():
        record = records.setdefault(identity, {'failures': 0, 'active': False})
        if good:
            c = dict(upstream[identity], number=registry[identity])
            record.update(channel=c, active=True, failures=0, last_success=now)
        else:
            record['failures'] = record.get('failures', 0) + 1
            if record['failures'] >= threshold:
                record['active'] = False
    channels = sorted([r['channel'] for r in records.values() if r.get('active')], key=lambda c: int(c['number']))
    feed = validate_feed(dict(schema_version=1, generated_at=now, source=SOURCE, channels=channels))
    new['last_scan'] = now
    if full:
        new['last_full'] = now
    return new, feed


def scan(state, full, workers=2):
    upstream = parse_source(download(SOURCE).decode('utf-8-sig'))
    old_source_count = state.get('source_count', 0)
    if old_source_count and len(upstream) < old_source_count * 0.75:
        raise ValueError('Upstream list shrank unexpectedly')
    records = state.get('records', {})
    identities = set(upstream) | set(records) if full else {i for i, r in records.items() if r.get('active')}
    if not identities:
        identities = set(upstream)
        full = True
    results = {}
    def check(identity):
        candidate = upstream.get(identity)
        good = bool(candidate and probe(candidate))
        # If a replacement URL fails, still test the previously verified stream.
        previous = records.get(identity, {}).get('channel')
        if not good and previous and (not candidate or previous['url'] != candidate['url']):
            if probe(previous):
                return identity, True, previous
        return identity, good, candidate
    with ThreadPoolExecutor(max_workers=workers) as pool:
        for identity, good, candidate in pool.map(check, sorted(identities)):
            results[identity] = good
            if good:
                upstream[identity] = candidate
            if len(results) % 50 == 0:
                LOG.info('Checked %d/%d; %d passed', len(results), len(identities), sum(results.values()))
    now = datetime.now(timezone.utc).isoformat()
    new, feed = evolve(state, upstream, results, full, now)
    new['source_count'] = len(upstream)
    LOG.info('Scan complete: %d checked, %d passed, %d retained', len(results), sum(results.values()), len(feed['channels']))
    return new, feed


def publish_github(feed, options):
    """One atomic content update. Token stays in HA options, never on the Pi."""
    repo, token = options.get('github_repository', ''), options.get('github_token', '')
    if not repo or not token:
        return False
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repo):
        raise ValueError('Invalid repository')
    url = f'https://api.github.com/repos/{repo}/contents/channels.json'
    headers = {'Authorization': f'Bearer {token}', 'Accept': 'application/vnd.github+json',
               'User-Agent': 'ChannelBox-Scanner', 'X-GitHub-Api-Version': '2022-11-28'}
    data = {'message': 'Refresh verified US channels', 'branch': 'main',
            'content': base64.b64encode(json.dumps(feed, ensure_ascii=False, indent=2).encode()).decode()}
    try:
        with urllib.request.urlopen(urllib.request.Request(url + '?ref=main', headers=headers), timeout=30) as response:
            data['sha'] = json.load(response)['sha']
    except urllib.error.HTTPError as error:
        if error.code != 404:
            raise
    with urllib.request.urlopen(urllib.request.Request(url, data=json.dumps(data).encode(), headers=headers, method='PUT'), timeout=30) as response:
        if response.status not in (200, 201):
            raise RuntimeError('GitHub publication failed')
    return True


def due(state, now, hour):
    today = now.date().isoformat()
    if now.hour < hour or state.get('last_scan_day') == today:
        return None
    last = state.get('last_full')
    full = not last or (now - datetime.fromisoformat(last)).total_seconds() >= 7 * 86400
    return full


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', type=Path, default=Path('/data'))
    parser.add_argument('--once', action='store_true')
    parser.add_argument('--full', action='store_true')
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    args.data.mkdir(parents=True, exist_ok=True)
    lock_file = (args.data / 'scanner.lock').open('w')
    fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    state_path = args.data / 'scanner-state.json'
    state = json.loads(state_path.read_text()) if state_path.exists() else {'numbers': json.loads(Path(__file__).with_name('numbers.json').read_text()), 'records': {}}
    while True:
        try:
            options = json.loads((args.data / 'options.json').read_text())
            now = datetime.now(ZoneInfo(options.get('timezone', 'America/Chicago')))
            full = True if args.full else due(state, now, options.get('scan_hour', 4))
            if args.once or full is not None:
                new, feed = scan(state, bool(full), options.get('workers', 2))
                new['last_scan_day'] = now.date().isoformat()
                new['publish_pending'] = True
                # Save a good scan before upload; publication retries never rescan or add failures.
                atomic_write(args.data / 'channels.json', json.dumps(feed, ensure_ascii=False, indent=2))
                atomic_write(args.data / 'channels.m3u', render_m3u(feed['channels']))
                atomic_write(state_path, json.dumps(new, ensure_ascii=False, indent=2))
                state = new
            if state.get('publish_pending'):
                feed = json.loads((args.data / 'channels.json').read_text())
                if publish_github(feed, options):
                    state['publish_pending'] = False
                    atomic_write(state_path, json.dumps(state))
                    LOG.info('Published %d channels to GitHub', len(feed['channels']))
                else:
                    LOG.info('Scan saved locally; GitHub repository/token not configured')
            if args.once:
                return
            time.sleep(300)
        except Exception as error:
            # Exception text can include tokens or stream addresses: print type only.
            LOG.error('Scan or publication failed (%s); previous playlist retained', type(error).__name__)
            if args.once:
                raise SystemExit(1)
            time.sleep(3600)


if __name__ == '__main__':
    main()
